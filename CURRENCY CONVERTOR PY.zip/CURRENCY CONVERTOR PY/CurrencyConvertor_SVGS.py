from tkinter import *
from tkinter import messagebox


# Creating a converting function

def convert_to_usd():
    usd = 0.0125 * value.get()
    messagebox.showinfo("USD", usd)


def convert_to_iqd():
    iqd = 18.3109 * value.get()
    messagebox.showinfo("IQD", iqd)


def convert_to_aud():
    aud = 0.018 * value.get()
    messagebox.showinfo("AUD", aud)


def convert_to_cad():
    cad = 0.0161 * value.get()
    messagebox.showinfo("CAD", cad)


def convert_to_eur():
    eur = 0.0123 * value.get()
    messagebox.showinfo("EUR", eur)


def convert_to_idr():
    idr = 187.1791 * value.get()
    messagebox.showinfo("IDR", idr)


def convert_to_jpy():
    jpy = 1.7099 * value.get()
    messagebox.showinfo("JPY", jpy)


def convert_to_kwd():
    kwd = 0.0039 * value.get()
    messagebox.showinfo("KWD", kwd)


def convert_to_myr():
    myr = 0.0559 * value.get()
    messagebox.showinfo("MYR", myr)


def convert_to_nzd():
    nzd = 0.02 * value.get()
    messagebox.showinfo("NZD", nzd)


def convert_to_php():
    php = 0.7006 * value.get()
    messagebox.showinfo("PHP", php)


def convert_to_sgd():
    sgd = 0.0174 * value.get()
    messagebox.showinfo("SGD", sgd)

# Creating a Window


currencyCal = Tk()
currencyCal.title("Currency Calculator")
currencyCal.geometry("300x400")
currencyCal.minsize(300, 400)
currencyCal.maxsize(300, 400)
currencyCal.configure( borderwidth=0, bg="white")

# Importing the image

img1  = PhotoImage(file='click_here.png')
img2  = PhotoImage(file='dollar-symbol (1).png')
img3  = PhotoImage(file='iran.png')
img4  = PhotoImage(file='australian-dollar.png')
img5  = PhotoImage(file='canadian-dollar (1).png')
img6  = PhotoImage(file='Euro-coin.png')
img7  = PhotoImage(file='indonesian-rupiah.png')
img8  = PhotoImage(file='yen.png')
img9  = PhotoImage(file='dinar.png')
img10 = PhotoImage(file='ringgit.png')
img11 = PhotoImage(file='new-zealand.png')
img12 = PhotoImage(file='philippine-peso.png')
img13 = PhotoImage(file='singapore-dollar.png')
img14 = PhotoImage(file='rupee.png')

# Creating a Title Label

heading = Label(currencyCal, text="CURRENCY CALCULATOR", bg="white", fg="black", font="arial 15 bold")
heading.place(x=18, y=25)

# Creating input label

value = IntVar()
currencyInput = Label(currencyCal, text="Enter value in INR(.Rs)", bg="white", font="arial 10 bold")
currencyInput.place(x=70, y=80)
currencyValue = Entry(currencyCal, fg="black", textvariable=value, font="arial 10 bold")
currencyValue.place(x=80, y=120)
INRiconlabel = Label(currencyCal, text=" ", image=img14, compound='left', bg="white")
INRiconlabel.place(x=220, y=120)

# Creating a convertor widget

currencyConvertor = Menubutton(currencyCal, image=img1, borderwidth=0, font="arial 10 bold", bg="pink", fg="red")
currencyConvertor.menu = Menu(currencyConvertor, tearoff=0)
currencyConvertor["menu"] = currencyConvertor.menu
currencyConvertor.menu.add_command(label="Convert to USD", image=img2, compound='left' ,font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_usd)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to IQD", image=img3, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_iqd)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to AUD", image=img4, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_aud)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to CAD", image=img5, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_cad)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to EUR", image=img6, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_eur)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to IDR", image=img7, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_idr)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to JPY", image=img8, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_jpy)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to KWD", image=img9, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_kwd)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to MYR", image=img10, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_myr)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to NZD", image=img11, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_nzd)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to PHP", image=img12, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_php)
currencyConvertor.menu.add_separator()
currencyConvertor.menu.add_command(label="Convert to SGD", image=img13, compound='left' , font="arial 10 bold", background="beige", activeforeground="green", activebackground="blue", command=convert_to_sgd)
currencyConvertor.menu.add_separator()
currencyConvertor.place(x=75, y=140)

currencyCal.mainloop()
